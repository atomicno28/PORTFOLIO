import { ReactComponent as ReactLogo } from "./react.svg";

export { ReactLogo };
{/* <Close width="32" height="32" /> */}
